"""Paper-only local web dashboard and polling worker. Standard library only."""
import json, math, statistics, time, threading, os, sqlite3, urllib.request, urllib.parse
from datetime import datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from engine import Snapshot, Ledger
K='https://api.elections.kalshi.com/trade-api/v2'
C='https://api.exchange.coinbase.com'
TIMING=int(os.getenv('PULSE_REMAINING','300'))
if TIMING not in (480,300,180,120,60,30): raise ValueError('invalid timing')
DB=os.getenv('PULSE_DB','pulse.sqlite3'); STATE={'status':'Starting','mode':'UNVALIDATED PAPER ONLY'}; mutex=threading.Lock()
def get(url):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PulseV2/1.0','Accept':'application/json'}),timeout=4) as r: return json.load(r)
def epoch(s): return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
def ema(xs,n):
 v=xs[0]; a=2/(n+1)
 for x in xs[1:]: v+=a*(x-v)
 return v
def indicators(candles,now):
 rows=sorted([r for r in candles if r[0]+60<=now]); rows=rows[-40:]
 if len(rows)<35 or any(b[0]-a[0]!=60 for a,b in zip(rows,rows[1:])) or now-rows[-1][0]>120: raise ValueError('missing or stale candles')
 x=[float(r[4]) for r in rows]; d=[b-a for a,b in zip(x,x[1:])]; g=sum(max(v,0) for v in d[-14:]); l=sum(max(-v,0) for v in d[-14:]); sig=statistics.stdev(math.log(b/a) for a,b in zip(x[-16:-1],x[-15:]))
 return {'sigma':sig,'rsi':100*g/(g+l) if g+l else 50,'macd':ema(x,12)-ema(x,26),'momentum':x[-1]/x[-2]-1,'volume':rows[-1][5]}
def market(now):
 data=get(K+'/markets?series_ticker=KXBTC15M&status=open&limit=100'); matches=[m for m in data['markets'] if epoch(m['open_time'])<=now<epoch(m['close_time']) and m['ticker'].startswith('KXBTC15M-')]
 if len(matches)!=1: raise ValueError('ambiguous active market')
 m=matches[0]; close=epoch(m['close_time']); opened=epoch(m['open_time']);
 if abs(close-opened-900)>1: raise ValueError('not 15-minute market')
 return m,close

def capture(m,close,ind):
 # Public REST receipt timestamps are not exchange quote timestamps. Reject absent source timestamps.
 ticker=m['ticker']; t=get(C+'/products/BTC-USD/ticker'); observed=epoch(t['time']); q=get(K+'/markets/'+urllib.parse.quote(ticker))['market']; saved=time.time()
 if q['ticker']!=ticker or epoch(q['close_time'])!=close: raise ValueError('market changed')
 # Do not infer quote time from HTTP receipt or market update metadata.
 if not q.get('quote_timestamp'): raise ValueError('exchange quote timestamp unavailable')
 qt=epoch(q['quote_timestamp']); strike=float(q['floor_strike']); rate=float(os.environ['PULSE_VERIFIED_FEE_RATE'])
 return Snapshot(ticker,close,observed,saved,qt,float(t['price']),strike,ind['sigma'],float(q['yes_ask_dollars']),float(q['no_ask_dollars']),float(q['yes_ask_size_fp']),float(q['no_ask_size_fp']),rate)
def settle_pending(ledger):
 for ticker,close in ledger.db.execute('SELECT d.ticker,d.close FROM decisions d LEFT JOIN settlements s ON d.ticker=s.ticker WHERE s.ticker IS NULL AND d.close<? LIMIT 10',(time.time(),)).fetchall():
  m=get(K+'/markets/'+urllib.parse.quote(ticker))['market']; result=m.get('result');
  if m['ticker']==ticker and epoch(m['close_time'])==close and m.get('status') in ('finalized','settled') and result in ('yes','no'): ledger.settle(ticker,'UP' if result=='yes' else 'DOWN',time.time())
def worker():
 ledger=Ledger(DB); last=None; snap=None; ind=None; ind_at=0; settled_at=0; reason='No fresh evidence'
 while True:
  try:
   now=time.time()
   if now-settled_at>60: settle_pending(ledger); settled_at=now
   if last is None or now>=last[1]: last=market(now); snap=None
   m,close=last; deadline=close-TIMING
   if now-ind_at>60: ind=indicators(get(C+'/products/BTC-USD/candles?granularity=60'),time.time()); ind_at=time.time()
   if now<deadline and deadline-now<20:
    try: snap=capture(m,close,ind); reason='No eligible evidence at deadline'
    except Exception as e: snap=None; reason=str(e)
   now=time.time()
   if now>=deadline:
    if snap and now<=deadline+1: ledger.record(snap,now,TIMING)
    else:
     with ledger.db: ledger.db.execute('INSERT OR IGNORE INTO decisions VALUES(?,?,?)',(m['ticker'],close,json.dumps({'direction':'SKIP','reason':reason if now<=deadline+1 else 'deadline missed','deadline':deadline,'evaluated_at':now})))
   with mutex: STATE.update(status='Polling — paper only',ticker=m['ticker'],close=close,deadline=deadline,indicators=ind,warning=reason if snap is None else None)
  except Exception as e:
   with mutex: STATE.update(status='DATA UNAVAILABLE — no forecast',warning=str(e))
  time.sleep(.25 if last and abs(last[1]-TIMING-time.time())<20 else 3)
def history():
 with sqlite3.connect(DB) as db:
  rows=db.execute('SELECT d.ticker,d.payload,s.result FROM decisions d LEFT JOIN settlements s ON d.ticker=s.ticker ORDER BY d.close DESC LIMIT 500').fetchall()
 out=[]
 for t,p,r in rows:
  p=json.loads(p); d=p['direction']; pnl=None if not r or d=='SKIP' else int(d==r)-p['ask']-p['fee']-.01
  out.append(dict(ticker=t,direction=d,result=r,pnl=pnl,reason=p.get('reason'),p_up=p.get('p_up'),deadline=p.get('deadline')))
 return out
HTML='''<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pulse V2</title><style>body{font:16px system-ui;background:#101820;color:#e8eef5;margin:20px;max-width:750px}section{background:#1d2935;padding:18px;border-radius:14px;margin:12px 0}h1{font-size:28px}small{color:#b7c5d4}table{width:100%;font-size:12px;text-align:left;overflow-wrap:anywhere}td{padding:7px 2px;border-bottom:1px solid #394655}strong{font-size:28px}</style><h1>Pulse V2</h1><small>UNVALIDATED · PAPER ONLY · No real orders</small><section id="live">Connecting…</section><section id="stats"></section><section><h3>Forecast history</h3><table id="hist"></table></section><script>function el(tag,txt){let e=document.createElement(tag);e.textContent=txt;return e}async function refresh(){try{let r=await fetch('/api/status',{cache:'no-store'}),s=await r.json(),h=s.history;let l=document.querySelector('#live');l.replaceChildren(el('div',s.status),el('h3',s.ticker||'No active market'),el('strong',s.close?Math.max(0,Math.floor(s.close-Date.now()/1000))+'s remaining':'—'),el('p',s.warning||''),el('small',JSON.stringify(s.indicators||{})));let a=h.filter(x=>x.pnl!==null),w=a.filter(x=>x.direction===x.result).length;document.querySelector('#stats').textContent=`Settled ${a.length} · Wins ${w} · Losses ${a.length-w} · Skips ${h.filter(x=>x.direction==='SKIP').length} · Simulated P&L $${a.reduce((v,x)=>v+x.pnl,0).toFixed(2)}`;let t=document.querySelector('#hist');t.replaceChildren();for(let x of h.slice(0,50)){let row=el('tr','');for(let v of [x.ticker,x.direction,x.result||'—',x.reason||''])row.append(el('td',v));t.append(row)}}catch(e){document.querySelector('#live').textContent='Dashboard connection unavailable'}}refresh();setInterval(refresh,2000)</script>'''
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path=='/': body=HTML.encode(); typ='text/html; charset=utf-8'
  elif self.path=='/api/status':
   with mutex: data=dict(STATE)
   data['history']=history(); body=json.dumps(data,allow_nan=False).encode(); typ='application/json'
  else: self.send_error(404); return
  self.send_response(200); self.send_header('Content-Type',typ); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body)
if __name__=='__main__':
 Ledger(DB).db.close(); threading.Thread(target=worker,daemon=True).start(); ThreadingHTTPServer((os.getenv('HOST','127.0.0.1'),int(os.getenv('PORT','8000'))),Handler).serve_forever()
