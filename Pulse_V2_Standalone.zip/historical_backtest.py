import json,zipfile,sys,math
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss,log_loss
from datetime import datetime
from pathlib import Path
z=zipfile.ZipFile(sys.argv[1]); d=json.loads(z.read('Bitcoin-Market-Pulse/generated-artifacts/lockdown-accuracy-audit-20261125/data.json'))
def ms(s): return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()*1000
rows=[]
for r in d['historical']:
 f=r['forecast']; q=f.get('executionQuote') or {}; t=f['predictedAt']; p=f.get('probabilityUp');
 if r['result'] not in ('yes','no') or p is None or not 0<=p<=1 or not t<f['closeAt'] or f.get('persistedAt',0)>f['closeAt'] or not 0<=t-ms(f['sourceTime'])<=6000: continue
 if not all(q.get(k) is not None for k in ['at','upAsk','upBid','downAsk','downBid','upSize','downSize','rate']): continue
 if not 0<=t-q['at']<=6000 or not 0<=q['upBid']<=q['upAsk']<=100 or not 0<=q['downBid']<=q['downAsk']<=100: continue
 rows.append((t,ms(r['first_observed_at']),r['ticker'],p,int(r['result']=='yes'),(q['upAsk']+q['upBid'])/200,q,int(f['btcPrice']>=f['targetPrice'])))
rows=sorted(rows); rows=list({r[2]:r for r in reversed(rows)}.values()); rows.sort(); cut=int(len(rows)*.6); testcut=int(len(rows)*.8); train=[r for r in rows[:cut] if r[1]<rows[cut][0]]; val=rows[cut:testcut]; test=rows[testcut:];
def logits(p):
 p=np.clip(p,1e-6,1-1e-6); return np.log(p/(1-p)).reshape(-1,1)
model=LogisticRegression(C=1).fit(logits([r[3] for r in train]),[r[4] for r in train]);
def metrics(rs,p):
 y=np.array([r[4] for r in rs]); p=np.array(p); wins=int(sum((p>=.5)==y)); pnl=[]
 for r,v in zip(rs,p):
  q=r[6]; up=v>=.5; a=q['upAsk' if up else 'downAsk']/100; size=q['upSize' if up else 'downSize'];
  if not 0<a<1 or size<1: continue
  fee=math.ceil(float(q['rate'])*a*(1-a)*100-1e-10)/100; pnl.append(float(up==bool(r[4]))-a-fee)
 return dict(n=len(rs),wins=wins,accuracy=wins/len(rs),brier=brier_score_loss(y,p),logloss=log_loss(y,np.clip(p,1e-6,1-1e-6)),fills=len(pnl),pnl=round(sum(pnl),4))
out={'eligible':len(rows),'train':len(train),'coefficient':float(model.coef_[0,0]),'intercept':float(model.intercept_[0]),'sets':{}}
for name,rs in [('validation',val),('later_test',test)]:
 out['sets'][name]={k:metrics(rs,p) for k,p in [('native',[r[3] for r in rs]),('calibrated',model.predict_proba(logits([r[3] for r in rs]))[:,1]),('midpoint',[r[5] for r in rs])]}
print(json.dumps(out,indent=2)); Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2))
