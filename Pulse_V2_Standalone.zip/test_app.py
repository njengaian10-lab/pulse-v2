import unittest,time
from app import indicators
class TestIndicators(unittest.TestCase):
 def test_contiguous(self):
  now=6000; rows=[[t,0,0,0,60000+(t%180),1] for t in range(3600,6000,60)]; self.assertGreater(indicators(rows,now)['sigma'],0)
 def test_gap(self):
  rows=[[t,0,0,0,60000,1] for t in range(3600,6000,60) if t!=4800]
  with self.assertRaises(ValueError): indicators(rows,6000)
if __name__=='__main__': unittest.main()
