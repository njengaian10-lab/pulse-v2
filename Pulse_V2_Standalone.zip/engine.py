"""Independent paper-only decision kernel. No network or trading credentials."""
from dataclasses import dataclass, asdict
import math, sqlite3, json
@dataclass(frozen=True)
class Snapshot:
    ticker:str; close:float; observed:float; saved:float; quote_at:float
    spot:float; strike:float; sigma_1m:float; up_ask:float; down_ask:float
    up_depth:float; down_depth:float; fee_rate:float

def decide(s, now, remaining=300):
    def skip(reason): return {'direction':'SKIP','reason':reason}
    if remaining not in (480,300,180,120,60,30): return skip('invalid timing')
    deadline=s.close-remaining
    if not all(math.isfinite(v) for k,v in asdict(s).items() if k!='ticker'): return skip('nonfinite input')
    if not s.ticker.startswith('KXBTC15M-'): return skip('wrong series')
    if not deadline<=now<=deadline+1: return skip('outside deadline')
    if not deadline-6<=s.observed<=s.saved<=deadline or not deadline-6<=s.quote_at<=deadline: return skip('stale or future evidence')
    if min(s.spot,s.strike,s.sigma_1m)<=0 or not 0<=s.fee_rate<=1: return skip('invalid inputs')
    if not all(0<a<1 for a in (s.up_ask,s.down_ask)) or s.up_ask+s.down_ask<1: return skip('invalid book')
    z=(s.spot-s.strike)/(s.spot*s.sigma_1m*math.sqrt(remaining/60))
    p=.5*(1+math.erf(z/math.sqrt(2)))
    direction='UP' if p>=.5 else 'DOWN'; confidence=max(p,1-p)
    ask,depth=(s.up_ask,s.up_depth) if direction=='UP' else (s.down_ask,s.down_depth)
    fee=math.ceil(s.fee_rate*ask*(1-ask)*100)/100
    edge=confidence-ask-fee-.01
    if confidence<.75 or not .50<=ask<=.75 or depth<1 or edge<.10: return skip('research entry filter') | {'p_up':p,'estimated_edge':edge}
    return {'direction':direction,'p_up':p,'ask':ask,'fee':fee,'estimated_edge':edge,'validated':False}

class Ledger:
    def __init__(self,path):
        self.db=sqlite3.connect(path); self.db.execute('CREATE TABLE IF NOT EXISTS decisions(ticker TEXT PRIMARY KEY, close REAL NOT NULL, payload TEXT NOT NULL)'); self.db.execute('CREATE TABLE IF NOT EXISTS settlements(ticker TEXT PRIMARY KEY, result TEXT NOT NULL)')
    def record(self,s,now,remaining=300):
        payload=decide(s,now,remaining); payload.update({'deadline':s.close-remaining,'evaluated_at':now,'snapshot':asdict(s)})
        with self.db: self.db.execute('INSERT OR IGNORE INTO decisions VALUES(?,?,?)',(s.ticker,s.close,json.dumps(payload,allow_nan=False)))
        return json.loads(self.db.execute('SELECT payload FROM decisions WHERE ticker=?',(s.ticker,)).fetchone()[0])
    def settle(self,ticker,result,now):
        row=self.db.execute('SELECT close,payload FROM decisions WHERE ticker=?',(ticker,)).fetchone()
        if not row or now<row[0] or result not in ('UP','DOWN'): raise ValueError('invalid settlement')
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO settlements VALUES(?,?)',(ticker,result))
            if self.db.execute('SELECT result FROM settlements WHERE ticker=?',(ticker,)).fetchone()[0]!=result: raise ValueError('conflicting settlement')
        p=json.loads(row[1]); return None if p['direction']=='SKIP' else int(p['direction']==result)-p['ask']-p['fee']-.01
