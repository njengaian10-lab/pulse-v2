import unittest
from dataclasses import replace
from engine import *
class Tests(unittest.TestCase):
 def setUp(self): self.s=Snapshot('KXBTC15M-test',1000,699,699.5,699,60100,60000,.0005,.60,.41,2,2,.07)
 def test_valid(self): self.assertEqual(decide(self.s,700)['direction'],'UP')
 def test_early(self): self.assertEqual(decide(self.s,699)['direction'],'SKIP')
 def test_late(self): self.assertEqual(decide(self.s,702)['direction'],'SKIP')
 def test_future(self): self.assertEqual(decide(replace(self.s,saved=701),700)['direction'],'SKIP')
 def test_stale(self): self.assertEqual(decide(replace(self.s,quote_at=690),700)['direction'],'SKIP')
 def test_expensive(self): self.assertEqual(decide(replace(self.s,up_ask=.98),700)['direction'],'SKIP')
 def test_depth(self): self.assertEqual(decide(replace(self.s,up_depth=0),700)['direction'],'SKIP')
 def test_immutable(self):
  l=Ledger(':memory:'); a=l.record(self.s,700); self.assertEqual(a,l.record(replace(self.s,spot=59000),700)); self.assertAlmostEqual(l.settle(self.s.ticker,'UP',1000),.37)
 def test_settlement(self):
  l=Ledger(':memory:'); l.record(self.s,700)
  with self.assertRaises(ValueError): l.settle(self.s.ticker,'UP',999)
  l.settle(self.s.ticker,'UP',1000)
  with self.assertRaises(ValueError): l.settle(self.s.ticker,'DOWN',1001)
if __name__=='__main__': unittest.main()
